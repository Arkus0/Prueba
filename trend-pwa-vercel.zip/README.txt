# Trend PWA

1. Sube esta carpeta a Vercel (New Project > Upload)
2. O arrastra a vercel.com
3. Se despliega como web instalable

Para APK: ve a pwabuilder.com, pega la URL de Vercel, genera Android package.
